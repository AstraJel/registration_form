﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Drawing.Text;
using System.IO;
using System.Linq;
using System.Net;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Net.Mime.MediaTypeNames;
using static System.Windows.Forms.VisualStyles.VisualStyleElement.ListView;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;
using System.Data.SqlClient;
using Image = System.Drawing.Image;

namespace Brozas_LabExer
{
    public partial class StudentForm : Form
    {
        public StudentForm()
        {
            InitializeComponent();
        }
        SqlConnection con = new SqlConnection(@"Data Source=DESKTOP-HKAL6VO\SQLEXPRESS;Initial Catalog=Brozas;Integrated Security=True");


        private void panel1_Paint(object sender, PaintEventArgs e)
        {
            
        }

        private void button1_Click(object sender, EventArgs e)
        {
            con.Open();
            SqlCommand cmd = new SqlCommand("Delete from register_Form where Student_ID= '" + textBox1.Text + "'", con);
            cmd.ExecuteNonQuery();
            con.Close();
            MessageBox.Show("Do you really want to delete?", "Confirmation", MessageBoxButtons.OK, MessageBoxIcon.Information);

        }

        public void SetImage(byte[] imageBytes)
        {
            using (MemoryStream ms = new MemoryStream(imageBytes))
            {
                Image image = Image.FromStream(ms);
                pictureBoxImage.Image = image;
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            con.Open();
            SqlCommand cmd = new SqlCommand("UPDATE register_Form Set Lastname= '" + textBox2.Text + "',Firstname='" + textBox3.Text + "',M_I='" + textBox4.Text + "',Gender='" + textBox5.Text + "',Bdate='" + textBox6.Text + "',Program='" + textBox7.Text + "' where Student_ID= '" + textBox1.Text + "'", con);
            cmd.ExecuteNonQuery();
            con.Close();
            MessageBox.Show("Successfully Update!");

        }
    }
}
