﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Brozas_LabExer
{
    public partial class Settings : Form
    {
        public Settings()
        {
            InitializeComponent();
        }
        SqlConnection con = new SqlConnection(@"Data Source=DESKTOP-HKAL6VO\SQLEXPRESS;Initial Catalog=Brozas;Integrated Security=True");

        private void button1_Click(object sender, EventArgs e)
        {
           
        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {
           
        }

        private void button2_Click(object sender, EventArgs e)
        {

            if (textBox4.Text != textBox5.Text)
            {
                MessageBox.Show("New password and confirm password do not match.");
                return;
            }
 
            con.Open();

           SqlCommand cmd = new SqlCommand("SELECT COUNT(*) FROM login WHERE Password = @password", con);
            cmd.Parameters.AddWithValue("@password", textBox3.Text);
            int count = (int)cmd.ExecuteScalar();
            if (count == 0)
            {
                MessageBox.Show("Username or old password is incorrect.");
                return;
            }
            cmd = new SqlCommand("UPDATE login SET Password = @newPassword", con);
            cmd.Parameters.AddWithValue("@newPassword", textBox4.Text);
            int rowsAffected = cmd.ExecuteNonQuery();

 
            con.Close();

            if (rowsAffected > 0)
            {
                MessageBox.Show("Password has been changed.");
                textBox3.Text = "";
                textBox4.Text = "";
                textBox5.Text = "";
            }
            else
            {
                MessageBox.Show("An error occurred while changing the password.");
            }
        }

        private void Settings_Load(object sender, EventArgs e)
        {

        }
    }
}
        
