﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace Brozas_LabExer
{
    public partial class Form2 : Form
    {
        Settings setting;
        Registration reg;
        Username user;
        Dashboard dash;
      

        bool sidebarExpand;
        bool menuExpand = false;
       
        public Form2()
        {
            InitializeComponent();
        }

        private void Form2_Load(object sender, EventArgs e)
        {
            
        }
  
        private void button1_Click(object sender, EventArgs e)
        {
           if (reg == null)
            {
                reg = new Registration();
                reg.FormClosed += Registration_FormClose;
                reg.MdiParent = this;
                reg.Show();

            }
            else
            {
                reg.Activate();
            }
        }
        private void Registration_FormClose(object sender, FormClosedEventArgs e)
        {
            reg = null;
        }


        private void sidebarTimer_Tick(object sender, EventArgs e)
        {
            
            if (sidebarExpand)
            {

                sidebar.Width -= 10;
                if (sidebar.Width == sidebar.MinimumSize.Width)
                {

                    sidebarExpand = false;
                    sidebarTimer.Stop();




                }
            }

            else
            {
                sidebar.Width +=10;
                if (sidebar.Width == sidebar.MaximumSize.Width)
                {

                    sidebarExpand = true;
                    sidebarTimer.Stop();


                   

                }
            }
        }

        private void menuButton_Click(object sender, EventArgs e)
        {
            sidebarTimer.Start();
        }

        private void flowLayoutPanel1_Paint(object sender, PaintEventArgs e)
        {

        }

        private void button5_Click(object sender, EventArgs e)
        {

        }

        private void button3_Click(object sender, EventArgs e)
        {
            Form1 form1 = new Form1();
            DialogResult result = MessageBox.Show("Are you sure you want to logout? ", "Confirmation", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
            if (result == DialogResult.Yes)
            {
                form1.Show();
                this.Hide();
            }
            else if (result == DialogResult.No)
            {

            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            menuTransation.Start();



        }

        private void menuTransation_Tick(object sender, EventArgs e)
        {
            if (menuExpand == false)
            {
                menuContainer.Height += 10;
                if (menuContainer.Height >= 179)
                {
                    menuTransation.Stop();
                    menuExpand = true;


                }
            }
            else
            {
                menuContainer.Height -= 10;
                if (menuContainer.Height <= 53)
                {
                    menuTransation.Stop();
                    menuExpand = false;

                }
            }
        }

        private void button7_Click(object sender, EventArgs e)
        {
            if (setting == null)
            {
                setting = new Settings();
                setting.FormClosed += Setting_FormClose;
                setting.MdiParent = this;
                setting.Show();

            }
            else
            {
                setting.Activate();
            }
        }
        private void Setting_FormClose(object sender, FormClosedEventArgs e)
        {
            setting = null;
            
        }

        private void button8_Click(object sender, EventArgs e)
        {
            if (user == null)
            {
                user = new Username();
                user.FormClosed += Username_FormClose;
                user.MdiParent = this;
                user.Show();

            }
            else
            {
                user.Activate();
            }
        }
        private void Username_FormClose(object sender, FormClosedEventArgs e)
        {
            user = null;
        }

        private void button5_Click_1(object sender, EventArgs e)
        {
            if (dash == null)
            {
                dash = new Dashboard();
                dash.FormClosed += Dashboard_FormClose;
                dash.MdiParent = this;
                dash.Show();

            }
            else
            {
                dash.Activate();
            }
        }
        private void Dashboard_FormClose(object sender, FormClosedEventArgs e)
        {
            dash = null;
        
    }
    }
    }

