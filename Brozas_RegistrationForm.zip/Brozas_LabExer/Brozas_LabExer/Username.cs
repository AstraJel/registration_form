﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Brozas_LabExer
{
    public partial class Username : Form
    {
        public Username()
        {
            InitializeComponent();
        }
        SqlConnection con = new SqlConnection(@"Data Source=DESKTOP-HKAL6VO\SQLEXPRESS;Initial Catalog=Brozas;Integrated Security=True");

        private void Username_Load(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {

            if (!string.IsNullOrEmpty(textBox1.Text))
            {
                if (textBox1.Text == textBox2.Text)
                {

                    String newUsername = textBox2.Text;

                    try
                    {

                        String sqlQuerry = "UPDATE login SET Username = '" + newUsername + "'";
                        SqlDataAdapter sda = new SqlDataAdapter(sqlQuerry, con);

                        DataTable dt = new DataTable();
                        sda.Fill(dt);

                        if (dt.Rows.Count > 0)
                        {
                            Form Form2 = new Form();
                            Form2.Show();
                            this.Hide();
                        }

                        MessageBox.Show("Your new username has been created successfully!", "New username Created", MessageBoxButtons.OK, MessageBoxIcon.Information);
                        textBox1.Text = "";
                        textBox2.Text = "";
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show(ex.Message);
                    }
                    finally
                    {
                        con.Close();
                    }
                }
                else
                {
                    MessageBox.Show("Must Enter the same username to confirm", " ", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
            }
        }

        private void pictureBox2_Click(object sender, EventArgs e)
        {

        }

        private void panel1_Paint(object sender, PaintEventArgs e)
        {

        }
    }
}
