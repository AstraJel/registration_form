﻿using Brozas_LabExer.BrozasDataSetTableAdapters;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Net.Mime.MediaTypeNames;
using Application = System.Windows.Forms.Application;

namespace Brozas_LabExer
{
    public partial class Dashboard : Form
    {
        public Dashboard()
        {
            InitializeComponent();
        }
        SqlConnection con = new SqlConnection(@"Data Source=DESKTOP-HKAL6VO\SQLEXPRESS;Initial Catalog=Brozas;Integrated Security=True");

        private void panel1_Paint(object sender, PaintEventArgs e)
        {

        }

       
        private void Dashboard_Load(object sender, EventArgs e)
        {
            // TODO: This line of code loads data into the 'brozasDataSet.register_Form' table. You can move, or remove it, as needed.
            this.register_FormTableAdapter.Fill(this.brozasDataSet.register_Form);
            con.Open();

            SqlCommand cmd = new SqlCommand("SELECT Username FROM login", con);

            // Execute the query and retrieve the username
            string username = (string)cmd.ExecuteScalar();

            // Set the label text to the retrieved username
            label2.Text = "Welcome, " + username;

            // Close the database connection
            con.Close();

            con.Open();
            SqlCommand c = new SqlCommand("SELECT * FROM register_Form", con);
            SqlDataAdapter d = new SqlDataAdapter(c);
            DataTable dta = new DataTable();
            d.Fill(dta);
            dataGridView1.DataSource = dta;
        }

        private void dataGridView1_CellDoubleClick(object sender, DataGridViewCellEventArgs e)
        {
            
            StudentForm f2 = new StudentForm();

            f2.textBox1.Text = this.dataGridView1.CurrentRow.Cells[0].Value.ToString();
            f2.textBox2.Text = this.dataGridView1.CurrentRow.Cells[1].Value.ToString();
            f2.textBox3.Text = this.dataGridView1.CurrentRow.Cells[2].Value.ToString();
            f2.textBox4.Text = this.dataGridView1.CurrentRow.Cells[3].Value.ToString();
            f2.textBox5.Text = this.dataGridView1.CurrentRow.Cells[4].Value.ToString();
            f2.textBox6.Text = this.dataGridView1.CurrentRow.Cells[5].Value.ToString();
            f2.textBox7.Text = this.dataGridView1.CurrentRow.Cells[6].Value.ToString();

            byte[] studImage = (byte[])this.dataGridView1.CurrentRow.Cells[7].Value;
            
            if (f2 != null)
            {
                f2.SetImage(studImage);
            } 

            f2.ShowDialog(); 

        }

        private void button1_Click(object sender, EventArgs e)
        {

               
               
        
    }

        private void button2_Click(object sender, EventArgs e)
        {
            SqlCommand c = new SqlCommand("SELECT * FROM register_Form", con);
            SqlDataAdapter d = new SqlDataAdapter(c);
            DataTable dta = new DataTable();
            d.Fill(dta);
            dataGridView1.DataSource = dta;

            
        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (comboBox1.SelectedIndex >= 0)
            {

                SqlCommand cmd = new SqlCommand("SELECT * FROM register_Form WHERE Program = '" + comboBox1.SelectedItem.ToString() + "'", con);
                SqlDataAdapter d = new SqlDataAdapter(cmd);
                DataTable dt = new DataTable();
                d.Fill(dt);

                dataGridView1.DataSource = dt;
                con.Close();
            }
            else
            {
            }
        }
    }
}
