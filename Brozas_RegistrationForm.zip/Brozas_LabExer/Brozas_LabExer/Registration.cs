﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
using System.Drawing.Imaging;
using System.IO;
using System.Xml.Linq;

namespace Brozas_LabExer
{
    public partial class Registration : Form
    {
        public Registration()
        {
            InitializeComponent();
        }
        SqlConnection con = new SqlConnection(@"Data Source=DESKTOP-HKAL6VO\SQLEXPRESS;Initial Catalog=Brozas;Integrated Security=True");
        private void pictureBox1_Click(object sender, EventArgs e)
        {

        }

        private void Registration_Load(object sender, EventArgs e)
        {
           

        }

        private void button2_Click(object sender, EventArgs e)
        {
            // Get the student's information from the form controls

            string Lname = textBox2.Text;
            string StudentID = textBox1.Text;
            string Fname = textBox3.Text;
            string Mname = textBox4.Text, gender = " ";

            string course = comboBox1.Text;
            DateTime bdate = DateTime.Parse(dateTimePicker1.Text);
            if (string.IsNullOrEmpty(Lname) || string.IsNullOrEmpty(Fname) || string.IsNullOrEmpty(Mname))
            {

                MessageBox.Show("Please fill in all fields.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }
            if (radioButton1.Checked == true)
            {
                gender = "Female";
            }
            else
            {
                gender = "Male";
            }

            // Get the student's image from the picture box
            byte[] image = null;
            if (pictureBox2.Image != null)
            {
                MemoryStream ms = new MemoryStream();
                pictureBox2.Image.Save(ms, ImageFormat.Jpeg);
                image = ms.ToArray();
            }

            // Connect to the database and insert the student's information and image
           
                con.Open();
                string query = "INSERT INTO register_Form (Student_ID, Lastname, Firstname, M_I, Gender, Bdate, Program, Picture) VALUES (@StudentID, @Lname, @Fname, @Mname, @gender, @bdate, @course, @image)";
                SqlCommand command = new SqlCommand(query, con);
                command.Parameters.AddWithValue("@StudentID", StudentID);
                command.Parameters.AddWithValue("@Lname", Lname);
                command.Parameters.AddWithValue("@Fname", Fname);
                command.Parameters.AddWithValue("@Mname", Mname);
                command.Parameters.AddWithValue("@gender", gender);
                command.Parameters.AddWithValue("@bdate", bdate);
                command.Parameters.AddWithValue("@course", course);
                command.Parameters.AddWithValue("@image", image);
                command.ExecuteNonQuery();
                MessageBox.Show("Successfully inserted");
            con.Close();
            textBox1.Text = "";
            textBox2.Text = "";
            textBox3.Text = "";
            textBox4.Text = "";
            dateTimePicker1.Value = DateTime.Now;
            radioButton1.Checked = false;
            radioButton2.Checked = false;
            comboBox1.Text = "  ";
            pictureBox2.Image = null;
           
        }
            private void button1_Click(object sender, EventArgs e)
            {
            OpenFileDialog openFileDialog = new OpenFileDialog();
            openFileDialog.Filter = "Image Files (*.bmp; *.jpg; *.png)|*.bmp;*.jpg;*.png";

            if (openFileDialog.ShowDialog() == DialogResult.OK)
            {
                pictureBox2.Image = new Bitmap(openFileDialog.FileName);
            }
        }

        private void button3_Click(object sender, EventArgs e)
        {
            textBox1.Text = "";
            textBox2.Text = "";
            textBox3.Text = "";
            dateTimePicker1.Value = DateTime.Now;
            radioButton1.Checked = false;
            radioButton2.Checked = false;
            comboBox1.Text = "  ";
            pictureBox2.Image = null;
        }
    }
    }
